import os
import shutil
import zipfile

# while True:
#     input()
#     print('1. Распечатать текущую директорию.')
#     print(os.getcwd())
#     print('Yes')
#     input()
#     print('2. Распечатать логин текущего пользователя операционной системы.')
#     print(os.getlogin())
#     print('Yes')
#     input()
#     print('3. Распечатать тип операционной системы, расшифровать результат.')
#     d = {"nt": "Windows ", "posix": "Unix"}
#     print(d[os.name])
#     print('Yes')
#     input()
#     print('4. Проверить, существует ли файл "test.txt".')
#     if os.path.isfile('test.txt'):
#         print('Yes')
#     else:
#         print('No')
#     print('Yes')
#     input()
#     print('5. Распечатать содержимое текущей папки.')
#     for i in os.listdir():
#         print(i)
#     print('Yes')
#     input()
#     print('6. Распечатать файловую структуру текущей директории с учётом вложенности.')
#     s = os.getcwd()
#     print(s)
#     print('Yes')
#     input()
#     print('7. Создать папку "test", предварительно проверив её отсутствие.')
#     if not os.path.isdir('test'):
#         os.mkdir('test')
#     else:
#         print('Уже есть')
#     print('Yes')
#     input()
#     print('8. Перейти в созданную папку "test" и убедиться, что она теперь является текущей.')
#     os.chdir('test')
#     print(os.getcwd())
#     print('Yes')
#     input()
#     print('9. Запросить у пользователя имя файла и создать файл с таким именем в текущей папке, записав в него своё имя.')
#     n = input()
#     with open(n, 'w') as file:
#         file.write('gleb')
#     print('Yes')
#     input()
#     print('10. Проверить, успешно ли создан файл и является ли он файлом или папкой.')
#     if os.path.isfile(n):
#         print('file')
#     elif os.path.isdir(n):
#         print('dir')
#     else:
#         print('none')
#     print('Yes')
#     input()
#     print('11. Распечатать абсолютный путь до созданного файла и его размер.')
#     print(os.path.abspath(n), os.stat(n).st_size)
#     print('Yes')
#     input()
#     print('12. Скопировать файл на уровень выше под тем же именем.')
#     shutil.copy2(os.path.abspath(n), os.getcwd()[:-4] + n)
#     print('Yes')
#     input()
#     print('13. Подняться на уровень выше и ещё раз распечатать содержимое папки с учётом вложенности.')
#
#     os.chdir('..')
#     print(os.listdir())
#     print('Yes')
#     input()
#     print('14. Распечатать содержимое скопированного файла.')
#     with open(n) as file:
#         print(file.readline())
#     print('Yes')
#     input()
#     print('15. Удалить папку "test" со всем содержимым.')
#     print(os.path.abspath('test'))
#     shutil.rmtree(os.path.abspath('test'))
#     print('Yes')
#     input()
#     print('16. Удалить скопированный файл из текущей папки.')
#     os.remove(n)
#     print('Yes')
#     input()
#     print('17. Убедиться, что в текущей папке больше нет папки "test" и созданного нами файла.')
#     if not os.path.isdir('test'):
#         print('Del "test"')
#     else:
#         print('No')
#     if not os.path.isfile(n):
#         print(f'Del {n}')
#     else:
#         print('No')
#     print('Yes')
#     break


def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))


if __name__ == '__main__':
    zipf = zipfile.ZipFile('Python.zip', 'w', zipfile.ZIP_DEFLATED)
    zipdir(os.getcwd(), zipf)
    zipf.close()
    with zipfile.ZipFile('new_file', 'r') as myzip:
        print(myzip.getinfo(myzip.namelist()[0]).file_size)
        print(myzip.read(myzip.namelist()[0]))
        if not os.path.isfile('new_file'):
            os.mkdir('new_file1')
        myzip.extractall('new_file1')